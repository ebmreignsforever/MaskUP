System.register([],(function(e){"use strict";return{execute:function(){e("default","assets/spine-u3j38j0v.wasm")}}}));
